import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './repayment-plan-app.component.html',
  styleUrls: ['./repayment-plan-app.component.scss']
})
export class RepaymentPlanAppComponent {
  title = 'Tilgungsplan';
}
