import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { RepaymentPlanAppRoutingModule } from './repayment-plan-app-routing.module';
import { RepaymentPlanAppComponent } from './repayment-plan-app.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { InitialParametersFormComponent } from './initial-parameters-form/initial-parameters-form.component';
import { CalculationResultTableComponent } from './calculation-result-table/calculation-result-table.component';
import { ReactiveFormsModule } from "@angular/forms";
import { InputToWholePositiveNumberDirective } from './common/input-to-whole-number.directive';
import { InputToPositiveDecimalDirective } from './common/input-to-positive-decimal.directive';
import { RepaymentPlanCalculatorService } from "./repaiment-plan-calculator.service";

@NgModule({
  declarations: [
    RepaymentPlanAppComponent,
    InitialParametersFormComponent,
    CalculationResultTableComponent,
    InputToWholePositiveNumberDirective,
    InputToPositiveDecimalDirective,
  ],
  imports: [
    BrowserModule,
    RepaymentPlanAppRoutingModule,
    MDBBootstrapModule.forRoot(),
    ReactiveFormsModule
  ],
  providers: [RepaymentPlanCalculatorService],
  bootstrap: [RepaymentPlanAppComponent]
})
export class RepaymentPlanAppModule { }
