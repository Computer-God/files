import { TestBed } from '@angular/core/testing';

import { RepaimentPlanCalculatorService } from './repaiment-plan-calculator.service';

describe('RepaimentPlanCalculatorService', () => {
  let service: RepaimentPlanCalculatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RepaimentPlanCalculatorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
