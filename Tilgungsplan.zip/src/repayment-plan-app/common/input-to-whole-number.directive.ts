import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: 'input[appInputToWholePositiveNumber]'
})
export class InputToWholePositiveNumberDirective {
  constructor(private el: ElementRef) {}

  @HostListener('change', ['$event']) onChange() {
    if (this.el.nativeElement.value < 0) {
      this.el.nativeElement.value = 0;
    }
  }

  @HostListener('keydown', ['$event']) onKeyDown(event: KeyboardEvent) {
    if(['-','+', '.', ','].includes(event.key)) {
      event.preventDefault();
    }
  }
}
