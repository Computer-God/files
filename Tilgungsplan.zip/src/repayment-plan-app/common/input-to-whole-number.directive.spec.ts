import { InputToWholeNumberDirective } from './input-to-whole-number.directive';

describe('InputToWholeNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new InputToWholeNumberDirective();
    expect(directive).toBeTruthy();
  });
});
