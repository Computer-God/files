import { InputtopositivedecimalDirective } from './input-to-positive-decimal.directive';

describe('InputtopositivedecimalDirective', () => {
  it('should create an instance', () => {
    const directive = new InputtopositivedecimalDirective();
    expect(directive).toBeTruthy();
  });
});
