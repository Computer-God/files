import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RepaymentPlanAppComponent } from './repayment-plan-app.component';

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        RepaymentPlanAppComponent
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(RepaymentPlanAppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'Tilgungsplan'`, () => {
    const fixture = TestBed.createComponent(RepaymentPlanAppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('Tilgungsplan');
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(RepaymentPlanAppComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.content span')?.textContent).toContain('Tilgungsplan app is running!');
  });
});
