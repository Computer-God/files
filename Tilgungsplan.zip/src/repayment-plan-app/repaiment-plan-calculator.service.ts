import { Injectable, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { takeWhile } from 'rxjs/operators';
import { initialParametersDto, RepaymentPlan, repaymentRowDto } from './repayment-plan-app.model';

@Injectable({
  providedIn: 'root'
})
export class RepaymentPlanCalculatorService implements OnDestroy{

  /** FormDataStream */
  public formDataStream$$: Subject<initialParametersDto> = new Subject();
  /** CalculatedRepaymentPlanDataStream */
  public calculatedRepaymentPlanDataStream$$: Subject<RepaymentPlan> = new Subject();
  /** How to deal with residual, true means 1 cent will be added to each payment and last payment will be less */
  private residualAddPaymentStrategy = false;
  /** Som folks like whole numbers */
  private noCentsFlag = false;
  /** Unsubscriber */
  public rxAlive = true;

  constructor() {
    this.formDataStream$$.pipe(takeWhile(() => this.rxAlive)).subscribe(formData => {
      this.calculateRepaymentPlan(<initialParametersDto>formData)
    });
  }

  /** Main payment plan calculation job
   * @emits Observable array of objects typed as RepaymentPlan
   * @param formData - form control values
   */
  private calculateRepaymentPlan = (formData: initialParametersDto): void => {
    const paymentPlan: RepaymentPlan = [{
      restDebtAmount: -formData.debtAmount,
      rateAmount: 0,
      repayedAmount: -formData.debtAmount,
      payment: -formData.debtAmount,
    }];
    const maxIterations = formData.paymentTermYears * 12;
    const monthlyPayment = this.calculatePercentAmount(
      formData,
      this.residualAddPaymentStrategy,
      this.noCentsFlag
    );
    const lastRow = {
      restDebtAmount: -formData.debtAmount,
      rateAmount: 0,
      repayedAmount: 0,
      payment: 0,
    };
    for(let i = 0; i < maxIterations && paymentPlan[i].restDebtAmount < 0; i++) {
      const paymentIteration = this.calculateNextRepaymentPlanRow(
        paymentPlan[i],
        paymentPlan[i].restDebtAmount <= -monthlyPayment ? monthlyPayment : Math.abs(paymentPlan[i].restDebtAmount),
        formData.bankLoanRate
      );
      lastRow.rateAmount += paymentIteration.rateAmount;
      lastRow.repayedAmount += paymentIteration.repayedAmount;
      lastRow.payment += paymentIteration.payment;
      paymentPlan.push(paymentIteration);
    }
    //Last row with summary
    paymentPlan.push({
      restDebtAmount: paymentPlan[paymentPlan.length - 1].restDebtAmount,
      rateAmount: this.twoDigitRound(lastRow.rateAmount),
      repayedAmount: this.twoDigitRound(lastRow.repayedAmount),
      payment: this.twoDigitRound(lastRow.payment),
    });

    this.calculatedRepaymentPlanDataStream$$.next(paymentPlan);
  }

  /** Calculates rate amount
   * @returns rate amount as number
   * @param data - form control values
   * @param residualAddPaymentStrategy - how to deal with residual, true does ceil, false - floor
   * @param noCentsFlag - flag to calculate amount without cents
   */
  private calculatePercentAmount (
    data: {
      debtAmount: number,
      bankLoanRate: number,
      initialRepaymentRate: number,
    },
    residualAddPaymentStrategy: boolean,
    noCentsFlag: boolean
    ): number {
    const digits = noCentsFlag ? 0 : 2;
    const paymentDirty = ((data.debtAmount / 100) * (data.bankLoanRate + data.initialRepaymentRate)) / 12;
    return this.treatValue(paymentDirty, digits, residualAddPaymentStrategy);
  }

  /** Calculates monthly amounts
   * @returns monthly payment amounts as object typed repaymentRowDto
   * @param prevRepaymentRow - previous month payment amounts as object typed repaymentRowDto
   * @param paymentAmount - payment amount, calculated separately
   * @param bankLoanRate - loan rate
   */
  private calculateNextRepaymentPlanRow(
    prevRepaymentRow: repaymentRowDto,
    paymentAmount: number,
    bankLoanRate: number
  ): repaymentRowDto {
    const bankRateAmount = ((Math.abs(prevRepaymentRow.restDebtAmount) / 100) * bankLoanRate) / 12;
    const restDebtAmount = this.twoDigitRound((prevRepaymentRow.restDebtAmount + (paymentAmount - bankRateAmount)));
    // For last row - different calculation
    return prevRepaymentRow.payment > paymentAmount ? {
      restDebtAmount: 0,
      rateAmount: this.twoDigitRound(bankRateAmount),
      repayedAmount: Math.abs(this.twoDigitRound(prevRepaymentRow.restDebtAmount)),
      payment: this.twoDigitRound(paymentAmount + bankRateAmount),
    } : {
      restDebtAmount: restDebtAmount,
      rateAmount: this.twoDigitRound(bankRateAmount),
      repayedAmount: this.twoDigitRound(paymentAmount - bankRateAmount),
      payment: paymentAmount,
    }
  }

  private treatValue(value: number, digits: number = 2, useCeil = true): number {
    return useCeil ?
      Math.ceil(value * Math.pow(10, digits))/Math.pow(10, digits) :
      Math.floor(value * Math.pow(10, digits))/Math.pow(10, digits);
  }

  private twoDigitRound(value: number): number {
    return Math.round(value * 100)/100;
  }

  ngOnDestroy() {
    this.rxAlive = false;
  }
}
