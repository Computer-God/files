/** Form params */
export interface initialParametersDto {
  debtAmount: number;
  bankLoanRate: number;
  initialRepaymentRate: number;
  paymentTermYears: number;
}

/** Repayment Plan Row */
export interface repaymentRowDto {
  restDebtAmount: number;
  rateAmount: number;
  repayedAmount: number;
  payment: number;
  date?: string;
}

/** Repayment Plan */
export type RepaymentPlan = repaymentRowDto[];
