import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RepaymentPlanCalculatorService } from "../repaiment-plan-calculator.service";
import { debounceTime, takeWhile } from "rxjs/operators";

@Component({
  selector: 'app-initial-parameters-form',
  templateUrl: './initial-parameters-form.component.html',
  styleUrls: ['./initial-parameters-form.component.scss']
})
export class InitialParametersFormComponent implements OnInit, OnDestroy {

  /** Formstate object */
  public form: FormGroup;
  /** Unsubscriber */
  public rxAlive = true;

  public FORM_SETTINGS = {
    debtAmount: { initialValue: 100000, maxValue: 1000000, minValue: 1000},
    bankLoanRate: { initialValue: 2.12, maxValue: 50, minValue: 0.1},
    initialRepaymentRate: { initialValue: 2, maxValue: 100, minValue: 0.01},
    paymentTermYears: { initialValue: 10, maxValue: 60, minValue: 1},
  }

  constructor(private fb: FormBuilder, private calculationService: RepaymentPlanCalculatorService) {
    this.form = this.fb.group({
      debtAmount: [
        this.FORM_SETTINGS.debtAmount.initialValue,
        [
          Validators.required,
          Validators.max(this.FORM_SETTINGS.debtAmount.maxValue),
          Validators.min(this.FORM_SETTINGS.debtAmount.minValue)
        ]
      ],
      bankLoanRate: [
        this.FORM_SETTINGS.bankLoanRate.initialValue,
        [
          Validators.required,
          Validators.max(this.FORM_SETTINGS.bankLoanRate.maxValue),
          Validators.min(this.FORM_SETTINGS.bankLoanRate.minValue)
        ]
      ],
      initialRepaymentRate: [
        this.FORM_SETTINGS.initialRepaymentRate.initialValue,
        [
          Validators.required,
          Validators.max(this.FORM_SETTINGS.initialRepaymentRate.maxValue),
          Validators.min(this.FORM_SETTINGS.initialRepaymentRate.minValue)
        ]
      ],
      paymentTermYears: [
        this.FORM_SETTINGS.paymentTermYears.initialValue,
        [
        Validators.required,
          Validators.max(this.FORM_SETTINGS.paymentTermYears.maxValue),
          Validators.min(this.FORM_SETTINGS.paymentTermYears.minValue)
        ]
      ],
    });
  }

  ngOnInit(): void {
    this.form.valueChanges.pipe(
      takeWhile(() => this.rxAlive),
      debounceTime(500)
    ).subscribe(value => this.form.valid && this.calculationService.formDataStream$$.next(value));
    setTimeout(() => this.form.valid && this.calculationService.formDataStream$$.next(this.form.value));
  }

  ngOnDestroy() {
    this.rxAlive = false;
  }

}
