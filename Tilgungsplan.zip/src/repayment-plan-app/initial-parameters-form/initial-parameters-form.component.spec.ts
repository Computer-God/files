import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InitialParametersFormComponent } from './initial-parameters-form.component';

describe('InitialParametersFormComponent', () => {
  let component: InitialParametersFormComponent;
  let fixture: ComponentFixture<InitialParametersFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InitialParametersFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InitialParametersFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
