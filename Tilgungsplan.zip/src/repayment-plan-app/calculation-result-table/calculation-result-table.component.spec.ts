import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CalculationResultTableComponent } from './calculation-result-table.component';

describe('CalculationResultTableComponent', () => {
  let component: CalculationResultTableComponent;
  let fixture: ComponentFixture<CalculationResultTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CalculationResultTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CalculationResultTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
