import { Component, OnDestroy, OnInit } from '@angular/core';
import { RepaymentPlanCalculatorService } from '../repaiment-plan-calculator.service';
import { takeWhile } from "rxjs/operators";
import { RepaymentPlan } from "../repayment-plan-app.model";
import {
  endOfMonth,
  lightFormat,
  addMonths,
  startOfMonth
} from 'date-fns';

@Component({
  selector: 'app-calculation-result-table',
  templateUrl: './calculation-result-table.component.html',
  styleUrls: ['./calculation-result-table.component.scss']
})
export class CalculationResultTableComponent implements OnInit, OnDestroy {

  public readonly headElements = ['Datum', 'Restschuld', 'Zinsen', 'Tilgung(+) / Auszahlung(-)', 'Rate'];
  public repaymentPlanData: RepaymentPlan = [];
  /** Unsubscriber */
  public rxAlive = true;

  constructor(private calculationService: RepaymentPlanCalculatorService) { }

  ngOnInit(): void {
    this.calculationService.calculatedRepaymentPlanDataStream$$
      .pipe(takeWhile(() => this.rxAlive))
      .subscribe((repaymentPlanData) => {
        const currentDate = new Date();
        for(let i = 0; i < repaymentPlanData.length; i++) {
          repaymentPlanData[i].date = lightFormat(endOfMonth(addMonths(startOfMonth(currentDate), i)), 'dd.MM.yyyy');
        }

        this.repaymentPlanData = repaymentPlanData;
      })
  }

  ngOnDestroy() {
    this.rxAlive = false;
  }
}
